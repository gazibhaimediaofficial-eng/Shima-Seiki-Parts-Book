Shima Seiki Parts Book — Android Final Project
Target: Android 16 / API 36
Application ID: com.shimaseiki.partsbook
Version: 1.0.0

This is the Android wrapper project for the current Parts Book demo UI.
Open in Android Studio, install Android SDK Platform 36, sync Gradle, then Generate APK.
For a production release, use your own signing key and connect real backend services.
Real WhatsApp OTP, authentication, orders/delivery persistence, server authorization and secure
production data services are not faked in this offline build.
